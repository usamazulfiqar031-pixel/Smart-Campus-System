import streamlit as st

# Page Setup
st.set_page_config(
    page_title="Smart Campus System",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>

.main {
    background-color: #f5f5f5;
}

.title {
    font-size: 40px;
    font-weight: bold;
}

.subtitle {
    color: gray;
    margin-top: -10px;
}

.card {
    background-color: white;
    padding: 20px;
    border-radius: 15px;
    margin-bottom: 20px;
    box-shadow: 0px 2px 8px rgba(0,0,0,0.05);
}

.notification {
    background-color: #eef2ff;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 10px;
}

.assignment {
    background-color: #fafafa;
    padding: 15px;
    border-radius: 10px;
    border: 1px solid #eee;
    margin-bottom: 10px;
}

.event {
    background-color: #fafafa;
    padding: 15px;
    border-radius: 10px;
    border: 1px solid #eee;
    margin-bottom: 10px;
}

.login-box {
    width: 400px;
    margin: auto;
    margin-top: 80px;
    background: white;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0px 2px 10px rgba(0,0,0,0.1);
}

</style>
""", unsafe_allow_html=True)

# Session
if "login" not in st.session_state:
    st.session_state.login = False

# LOGIN PAGE
if not st.session_state.login:

    st.markdown("""
    <div class="login-box">

    <h1 style="text-align:center;color:#4f46e5;">
    Student Management System
    </h1>

    <p style="text-align:center;color:gray;">
    Sign in to your account
    </p>

    </div>
    """, unsafe_allow_html=True)

    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):

        if username and password:
            st.session_state.login = True
            st.rerun()

        else:
            st.error("Please enter username and password")

# DASHBOARD
else:

    # Header
    col1, col2 = st.columns([8,1])

    with col1:
        st.markdown(
            '<p class="title">Student Dashboard</p>',
            unsafe_allow_html=True
        )

        st.markdown(
            '<p class="subtitle">Welcome back, John Doe</p>',
            unsafe_allow_html=True
        )

    with col2:
        st.button("Logout")

    st.divider()

    # Layout
    left, right = st.columns([1,2])

    # LEFT COLUMN
    with left:

        # Notifications
        st.markdown('<div class="card">', unsafe_allow_html=True)

        st.subheader("🔔 Notifications")

        st.markdown("""
        <div class="notification">
        New assignment posted for Mathematics
        <br>
        <small>2 hours ago</small>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="notification">
        Your attendance has been marked for today
        <br>
        <small>4 hours ago</small>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="notification">
        Exam schedule updated
        <br>
        <small>1 day ago</small>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

        # Attendance
        st.markdown('<div class="card">', unsafe_allow_html=True)

        st.subheader("Attendance Status")

        st.write("Total Days: 45")
        st.write("Present: 42")
        st.write("Absent: 3")

        st.progress(93)

        st.markdown("### 93.3%")

        st.markdown("</div>", unsafe_allow_html=True)

    # RIGHT COLUMN
    with right:

        # Assignment Reminder
        st.markdown('<div class="card">', unsafe_allow_html=True)

        st.subheader("📘 Assignment Reminders")

        st.markdown("""
        <div class="assignment">
        <b>Chapter 5 Homework</b><br>
        Mathematics<br>
        Due Date: 2026-05-20
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="assignment">
        <b>Lab Report</b><br>
        Physics<br>
        Due Date: 2026-05-22
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="assignment">
        <b>Essay Submission</b><br>
        English<br>
        Due Date: 2026-05-18
        </div>
        """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

        # Events
        st.markdown('<div class="card">', unsafe_allow_html=True)

        st.subheader("📅 Upcoming Events")

        st.markdown("""
        <div class="event">
        <b>Mathematics Exam</b><br>
        9:00 AM
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="event">
        <b>Sports Day</b><br>
        8:00 AM
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="event">
        <b>Parent-Teacher Meeting</b><br>
        2:00 PM
        </div>
        """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)